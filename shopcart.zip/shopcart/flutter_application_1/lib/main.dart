import 'package:flutter/material.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Product Cart',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const CartScreen(),
    );
  }
}

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  final Map<String, int> _products = {
    'iPad': 19000,
    'iPad Mini': 23000,
    'iPad Air': 29000,
    'iPad Pro': 39000,
  };

  final Map<String, int> _cart = {
    'iPad': 0,
    'iPad Mini': 0,
    'iPad Air': 0,
    'iPad Pro': 0,
  };

  void _addProduct(String product) {
    setState(() {
      _cart[product] = _cart[product]! + 1; // เพิ่มจำนวนสินค้า
    });
  }

  void _removeProduct(String product) {
    setState(() {
      if (_cart[product]! > 0) {
        _cart[product] = _cart[product]! - 1; // ลดจำนวนสินค้า
      }
    });
  }

  void _clearCart() {
    setState(() {
      _cart.forEach((key, value) {
        _cart[key] = 0; // เคลียร์จำนวนสินค้า
      });
    });
  }

  String _formatCurrency(int amount) {
    return '฿${amount.toString().replaceAll(RegExp(r'(?<=\d)(?=(\d{3})+(?!\d))'), ',')}';
  }

  int get _totalPrice {
    int total = 0;
    _cart.forEach((product, quantity) {
      total += _products[product]! * quantity; // คำนวณราคารวม
    });
    return total;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Product Cart'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Products', style: TextStyle(fontSize: 24)),
            ..._products.keys.map((product) {
              return Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(product),
                  Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.remove),
                        onPressed: () => _removeProduct(product),
                      ),
                      Text('${_cart[product]}'),
                      IconButton(
                        icon: const Icon(Icons.add),
                        onPressed: () => _addProduct(product),
                      ),
                    ],
                  ),
                ],
              );
            }).toList(),
            const SizedBox(height: 20),
            Text('Total Price: ${_formatCurrency(_totalPrice)}', style: const TextStyle(fontSize: 20)),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _clearCart,
              child: const Text('Clear Cart'),
            ),
          ],
        ),
      ),
    );
  }
}
